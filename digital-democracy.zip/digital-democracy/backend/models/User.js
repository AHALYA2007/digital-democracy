// User model (for reference) - using lowdb so no ORM here.
// { id, name, username, password (plain for demo), role: 'Citizen'|'Politician' }
module.exports = {};
