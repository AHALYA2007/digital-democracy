// Suggestion model reference:
// { id, title, body, topic, author (username), votes_up, votes_down, status: 'Pending'|'Reviewed'|'Accepted', comments: [{user, text}] }
module.exports = {};
