const path = require('path');
module.exports = {
  DB_FILE: path.join(__dirname, '..', 'db.json')
};
