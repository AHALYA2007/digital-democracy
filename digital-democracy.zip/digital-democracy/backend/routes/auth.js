const express = require('express');
const router = express.Router();
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const { DB_FILE } = require('../config/database');

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter);

async function ensure() { await db.read(); db.data = db.data || { users: [], suggestions: [] }; }

// Register
router.post('/register', async (req, res) => {
  await ensure();
  const { name, username, password, role } = req.body;
  if (!name || !username || !password || !role) return res.status(400).json({ error: 'Missing fields' });
  const exists = db.data.users.find(u => u.username === username && u.role === role);
  if (exists) return res.status(400).json({ error: 'User exists' });
  const user = { id: nanoid(), name, username, password, role };
  db.data.users.push(user);
  await db.write();
  const safe = { id: user.id, name: user.name, username: user.username, role: user.role };
  res.json({ user: safe });
});

// Login
router.post('/login', async (req, res) => {
  await ensure();
  const { username, password, role } = req.body;
  if (!username || !password || !role) return res.status(400).json({ error: 'Missing fields' });
  const user = db.data.users.find(u => u.username === username && u.password === password && u.role === role);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const safe = { id: user.id, name: user.name, username: user.username, role: user.role };
  res.json({ user: safe });
});

module.exports = router;
