const express = require('express');
const router = express.Router();
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const { DB_FILE } = require('../config/database');

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter);

async function ensure() { await db.read(); db.data = db.data || { users: [], suggestions: [] }; }

// Create suggestion (politician posts OR citizen suggestion depending on UI) - allow both
router.post('/', async (req, res) => {
  await ensure();
  const { title, body, topic, author } = req.body;
  if (!title || !body || !topic || !author) return res.status(400).json({ error: 'Missing fields' });
  const s = { id: nanoid(), title, body, topic, author, votes_up:0, votes_down:0, status:'Pending', comments: [] };
  db.data.suggestions.push(s);
  await db.write();
  res.json({ suggestion: s });
});

// List suggestions (optionally filter by topic)
router.get('/', async (req, res) => {
  await ensure();
  const topic = req.query.topic;
  let list = db.data.suggestions;
  if (topic) list = list.filter(x => x.topic === topic);
  res.json({ suggestions: list });
});

// Comment on suggestion
router.post('/:id/comment', async (req, res) => {
  await ensure();
  const id = req.params.id;
  const { user, text } = req.body;
  const s = db.data.suggestions.find(x => x.id === id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  s.comments.push({ user, text });
  await db.write();
  res.json({ suggestion: s });
});

module.exports = router;
