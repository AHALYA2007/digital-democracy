const express = require('express');
const router = express.Router();
const { Low, JSONFile } = require('lowdb');
const { DB_FILE } = require('../config/database');

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter);

async function ensure() { await db.read(); db.data = db.data || { users: [], suggestions: [] }; }

router.get('/', async (req, res) => {
  await ensure();
  res.json({ users: db.data.users.map(u => ({ id:u.id, name:u.name, username:u.username, role:u.role })) });
});

module.exports = router;
