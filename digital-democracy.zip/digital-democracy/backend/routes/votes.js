const express = require('express');
const router = express.Router();
const { Low, JSONFile } = require('lowdb');
const { DB_FILE } = require('../config/database');

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter);

async function ensure() { await db.read(); db.data = db.data || { users: [], suggestions: [] }; }

router.post('/:id/up', async (req, res) => {
  await ensure();
  const id = req.params.id;
  const s = db.data.suggestions.find(x => x.id === id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  s.votes_up = (s.votes_up||0) + 1;
  await db.write();
  res.json({ suggestion: s });
});

router.post('/:id/down', async (req, res) => {
  await ensure();
  const id = req.params.id;
  const s = db.data.suggestions.find(x => x.id === id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  s.votes_down = (s.votes_down||0) + 1;
  await db.write();
  res.json({ suggestion: s });
});

router.post('/:id/status', async (req, res) => {
  await ensure();
  const id = req.params.id;
  const { status } = req.body;
  const s = db.data.suggestions.find(x => x.id === id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  s.status = status;
  await db.write();
  res.json({ suggestion: s });
});

module.exports = router;
