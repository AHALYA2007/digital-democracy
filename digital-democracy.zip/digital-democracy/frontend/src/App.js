import React, { useState, useEffect } from 'react';
import LanguageSelection from './components/LanguageSelection';
import RoleSelection from './components/RoleSelection';
import Login from './components/Login';
import Register from './components/Register';
import CitizenDashboard from './components/CitizenDashboard';
import PoliticianDashboard from './components/PoliticianDashboard';
import './App.css';

function App() {
  const [step, setStep] = useState('welcome'); // welcome -> role -> auth -> dashboard
  const [language, setLanguage] = useState(localStorage.getItem('language') || 'en');
  const [role, setRole] = useState(null);
  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('user') || 'null'));

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  useEffect(() => {
    if (user) {
      setStep('dashboard');
    }
  }, [user]);

  if (step === 'welcome') {
    return <LanguageSelection onContinue={() => setStep('role')} language={language} setLanguage={setLanguage} />;
  }
  if (step === 'role') {
    return <RoleSelection onSelect={(r)=>{setRole(r); setStep('auth')}} />;
  }
  if (step === 'auth') {
    return <div className='auth-wrap'><Login role={role} setUser={setUser} /><Register role={role} /></div>;
  }
  if (step === 'dashboard' && user) {
    if (user.role === 'Citizen') return <CitizenDashboard user={user} setUser={setUser} />;
    return <PoliticianDashboard user={user} setUser={setUser} />;
  }
  return <div>Loading...</div>;
}

export default App;
