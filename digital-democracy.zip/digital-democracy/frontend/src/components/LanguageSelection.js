import React from 'react';

export default function LanguageSelection({ onContinue, language, setLanguage }) {
  return (
    <div className="container">
      <img src="parliament.png" alt="parliament" style={{width:120}} />
      <h1>Digital Democracy</h1>
      <p>Select language:</p>
      <select value={language} onChange={(e)=>setLanguage(e.target.value)}>
        <option value="en">English</option>
        <option value="ta">தமிழ்</option>
        <option value="hi">हिन्दी</option>
      </select>
      <br/>
      <button onClick={onContinue}>Continue</button>
    </div>
  );
}
