import React from 'react';

export default function RoleSelection({ onSelect }) {
  return (
    <div className="container">
      <h2>Choose Role</h2>
      <button onClick={()=>onSelect('Citizen')}>Citizen</button>
      <button onClick={()=>onSelect('Politician')}>Politician</button>
    </div>
  );
}
