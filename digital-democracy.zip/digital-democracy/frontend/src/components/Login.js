import React, { useState } from 'react';

export default function Login({ role, setUser }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const submit = async () => {
    const res = await fetch('http://localhost:4000/api/auth/login', {
      method: 'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ username, password, role })
    });
    const data = await res.json();
    if (res.ok) {
      sessionStorage.setItem('user', JSON.stringify(data.user));
      setUser(data.user);
    } else {
      alert(data.error || 'Login failed');
    }
  };
  return (
    <div style={{flex:1}}>
      <h3>Login ({role})</h3>
      <input placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={submit}>Login</button>
    </div>
  );
}
