import React, { useEffect, useState } from 'react';

export default function CitizenDashboard({ user, setUser }) {
  const [suggestions, setSuggestions] = useState([]);
  const [topic, setTopic] = useState('Sports');
  const [selected, setSelected] = useState(null);
  const [comment, setComment] = useState('');

  useEffect(()=>{ load(); }, []);

  async function load() {
    const res = await fetch('http://localhost:4000/api/suggestions?topic=' + encodeURIComponent(topic));
    const data = await res.json();
    setSuggestions(data.suggestions || []);
  }
  async function addComment() {
    if (!selected) return alert('Select a suggestion');
    const res = await fetch('http://localhost:4000/api/suggestions/' + selected + '/comment', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ user: user.username, text: comment })
    });
    if (res.ok) { setComment(''); load(); }
  }
  async function vote(id, dir) {
    await fetch('http://localhost:4000/api/votes/' + id + '/' + (dir==='up'?'up':'down'), { method:'POST' });
    load();
  }

  return (
    <div className="container">
      <h2>Welcome, {user.name}</h2>
      <div>
        <label>Topic:</label>
        <select value={topic} onChange={e=>{setTopic(e.target.value); setTimeout(load,50);}}>
          <option>Sports</option><option>Finance & Economy</option><option>Agriculture</option><option>Education</option><option>Women Safety</option><option>Political Affairs</option>
        </select>
      </div>
      <div>
        <h3>Suggestions</h3>
        {suggestions.map(s=> (
          <div key={s.id} style={{border:'1px solid #ddd',padding:8,margin:6}}>
            <strong>{s.title}</strong> <em>({s.topic})</em>
            <p>{s.body}</p>
            <div>Votes: {s.votes_up} 👍 | {s.votes_down} 👎</div>
            <button onClick={()=>{setSelected(s.id)}}>Select</button>
            <button onClick={()=>vote(s.id,'up')}>Upvote</button>
            <button onClick={()=>vote(s.id,'down')}>Downvote</button>
            <div>Comments: {(s.comments||[]).map((c,i)=>(<div key={i}><strong>{c.user}</strong>: {c.text}</div>))}</div>
          </div>
        ))}
      </div>
      <div>
        <h4>Add comment to selected</h4>
        <input value={comment} onChange={e=>setComment(e.target.value)} />
        <button onClick={addComment}>Submit Comment</button>
      </div>
      <button onClick={()=>{ sessionStorage.removeItem('user'); setUser(null); }}>Logout</button>
    </div>
  );
}
