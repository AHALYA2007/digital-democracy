import React, { useState } from 'react';

export default function Register({ role }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const submit = async () => {
    const res = await fetch('http://localhost:4000/api/auth/register', {
      method: 'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name, username, password, role })
    });
    const data = await res.json();
    if (res.ok) {
      alert('Registered. Now login.');
    } else {
      alert(data.error || 'Register failed');
    }
  };
  return (
    <div style={{flex:1}}>
      <h3>Register ({role})</h3>
      <input placeholder="name" value={name} onChange={e=>setName(e.target.value)} />
      <input placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={submit}>Register</button>
    </div>
  );
}
