import React, { useEffect, useState } from 'react';

export default function PoliticianDashboard({ user, setUser }) {
  const [suggestions, setSuggestions] = useState([]);
  const [title, setTitle] = useState('');
  const [topic, setTopic] = useState('Education');
  const [body, setBody] = useState('');

  useEffect(()=>{ loadAll(); }, []);

  async function loadAll() {
    const res = await fetch('http://localhost:4000/api/suggestions');
    const data = await res.json();
    setSuggestions(data.suggestions || []);
  }
  async function createPost() {
    const res = await fetch('http://localhost:4000/api/suggestions', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ title, body, topic, author: user.username })
    });
    if (res.ok) { setTitle(''); setBody(''); loadAll(); }
  }
  async function setStatus(id,status) {
    await fetch('http://localhost:4000/api/votes/' + id + '/status', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status })
    });
    loadAll();
  }

  return (
    <div className="container">
      <h2>Politician Dashboard - {user.name}</h2>
      <div style={{border:'1px solid #ddd', padding:10}}>
        <h3>Create Post</h3>
        <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
        <select value={topic} onChange={e=>setTopic(e.target.value)}>
          <option>Sports</option><option>Finance & Economy</option><option>Agriculture</option><option>Education</option><option>Women Safety</option><option>Political Affairs</option>
        </select>
        <textarea placeholder="body" value={body} onChange={e=>setBody(e.target.value)} />
        <button onClick={createPost}>Post</button>
      </div>
      <div>
        <h3>Top Suggestions</h3>
        {suggestions.sort((a,b)=>(b.votes_up - b.votes_down) - (a.votes_up - a.votes_down)).map(s=>(
          <div key={s.id} style={{border:'1px solid #eee', padding:8, margin:6}}>
            <strong>{s.title}</strong> <em>({s.topic})</em>
            <p>{s.body}</p>
            <div>Votes: {s.votes_up} 👍 | {s.votes_down} 👎</div>
            <div>Status: {s.status}</div>
            <button onClick={()=>setStatus(s.id,'Reviewed')}>Mark Reviewed</button>
            <button onClick={()=>setStatus(s.id,'Accepted')}>Mark Accepted</button>
            <div>Comments: {(s.comments||[]).map((c,i)=>(<div key={i}><strong>{c.user}</strong>: {c.text}</div>))}</div>
          </div>
        ))}
      </div>
      <button onClick={()=>{ sessionStorage.removeItem('user'); setUser(null); }}>Logout</button>
    </div>
  );
}
