# Digital Democracy
Minimal full-stack demo (Node.js backend + React frontend). See frontend/ and backend/ README for info.
